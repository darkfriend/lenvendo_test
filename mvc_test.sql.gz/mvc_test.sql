-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2014 at 10:13 PM
-- Server version: 5.5.25
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mvc_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `pass` varchar(36) NOT NULL,
  `data_auth` date NOT NULL,
  `privilege_id` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `login`, `pass`, `data_auth`, `privilege_id`) VALUES
(3, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2014-06-22', 1),
(4, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', '0000-00-00', 2),
(36, 'user2', '7e58d63b60197ceb55a1c487989a3720', '0000-00-00', 2),
(37, 'user3', '92877af70a45fd6a2ed7fe81e1236b78', '0000-00-00', 2),
(38, 'user4', '3f02ebe3d7929b091e3d8ccfde2f3bc6', '0000-00-00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_pictures`
--

CREATE TABLE IF NOT EXISTS `user_pictures` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `name_file` varchar(255) NOT NULL,
  `last_edit` datetime NOT NULL,
  `create_date` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name_file` (`name_file`),
  UNIQUE KEY `name_file_2` (`name_file`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user_pictures`
--

INSERT INTO `user_pictures` (`ID`, `id_user`, `name_file`, `last_edit`, `create_date`) VALUES
(1, 3, '1bce44e508a0766c06967f664a5e71ce.png', '2014-06-23 00:00:00', '06.2014'),
(2, 3, 'a692d94b8690ae82672b2c6740495a14.png', '2014-06-23 16:01:24', '06.2014');

-- --------------------------------------------------------

--
-- Table structure for table `user_privileges`
--

CREATE TABLE IF NOT EXISTS `user_privileges` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_privileges`
--

INSERT INTO `user_privileges` (`ID`, `name`) VALUES
(1, 'admin'),
(2, 'user');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
